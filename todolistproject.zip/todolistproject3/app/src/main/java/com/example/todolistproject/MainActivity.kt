package com.example.todolistproject

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.todolistproject.ui.theme.TodolistprojectTheme
import java.text.SimpleDateFormat
import java.util.*

data class User(val username: String, val password: String)
data class Task(val name: String, val date: String, val description: String, var isCompleted: Boolean = false)

class MainActivity : ComponentActivity() {
    private var registeredUsers = mutableListOf<User>()
    private var loggedInUser by mutableStateOf<User?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TodolistprojectTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (loggedInUser == null) {
                        AuthScreen(
                            onRegister = { user ->
                                registeredUsers.add(user)
                            },
                            onLogin = { user ->
                                val foundUser = registeredUsers.find {
                                    it.username == user.username && it.password == user.password
                                }
                                if (foundUser != null) {
                                    loggedInUser = foundUser
                                }
                            }
                        )
                    } else {
                        ToDoListApp(
                            onLogout = { loggedInUser = null }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(onRegister: (User) -> Unit, onLogin: (User) -> Unit) {
    var isLoginScreen by remember { mutableStateOf(true) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = if (isLoginScreen) "Login" else "Register", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation()
        )
        if (!isLoginScreen) {
            Spacer(modifier = Modifier.height(16.dp))
            TextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Confirm Password") },
                visualTransformation = PasswordVisualTransformation()
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (isLoginScreen) {
                onLogin(User(username, password))
            } else {
                if (password == confirmPassword) {
                    onRegister(User(username, password))
                } else {
                    errorMessage = "Passwords do not match"
                }
            }
        }) {
            Text(text = if (isLoginScreen) "Login" else "Register")
        }
        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = {
            isLoginScreen = !isLoginScreen
            errorMessage = ""
        }) {
            Text(text = if (isLoginScreen) "Switch to Register" else "Switch to Login")
        }
        if (errorMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = errorMessage, color = Color.Red)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToDoListApp(onLogout: () -> Unit) {
    var showTaskInput by remember { mutableStateOf(false) }
    var tasks by remember { mutableStateOf(listOf<Task>()) }
    var taskToEdit by remember { mutableStateOf<Task?>(null) }
    var showDeleteDialog by remember { mutableStateOf<Task?>(null) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text(text = "Hari Ini, 20/06/2024", color = Color.White) },
                actions = {
                    IconButton(onClick = { showLogoutDialog = true }) {
                        Icon(Icons.Filled.ExitToApp, contentDescription = "Logout")
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = Color(0xFF42A5F5)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showTaskInput = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Tambah Tugas")
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (showTaskInput) {
                TaskInputScreen(
                    onDismiss = { showTaskInput = false; taskToEdit = null },
                    onAddTask = { task ->
                        if (taskToEdit != null) {
                            tasks = tasks.map {
                                if (it == taskToEdit) task else it
                            }
                        } else {
                            tasks = tasks + task
                        }
                        showTaskInput = false
                        taskToEdit = null
                    },
                    taskToEdit = taskToEdit
                )
            } else {
                if (tasks.isEmpty()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Tidak ada tugas hari ini",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxSize()
                    ) {
                        Text(
                            text = "Hari Ini",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        val pendingTasks = tasks.filter { !it.isCompleted }
                        val completedTasks = tasks.filter { it.isCompleted }

                        pendingTasks.forEach { task ->
                            TaskCard(
                                task = task,
                                onEdit = {
                                    if (!task.isCompleted) {
                                        taskToEdit = task
                                        showTaskInput = true
                                    }
                                },
                                onDelete = {
                                    showDeleteDialog = task
                                },
                                onToggleComplete = {
                                    tasks = tasks.map {
                                        if (it == task) it.copy(isCompleted = !it.isCompleted) else it
                                    }
                                }
                            )
                        }

                        if (completedTasks.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Tugas Selesai",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            completedTasks.forEach { task ->
                                TaskCard(
                                    task = task,
                                    onEdit = {},
                                    onDelete = {
                                        showDeleteDialog = task
                                    },
                                    onToggleComplete = {
                                        tasks = tasks.map {
                                            if (it == task) it.copy(isCompleted = !it.isCompleted) else it
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            showDeleteDialog?.let { task ->
                AlertDialog(
                    onDismissRequest = { showDeleteDialog = null },
                    confirmButton = {
                        TextButton(onClick = {
                            tasks = tasks - task
                            showDeleteDialog = null
                        }) {
                            Text("Hapus")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteDialog = null }) {
                            Text("Batal")
                        }
                    },
                    title = { Text("Konfirmasi Hapus") },
                    text = { Text("Apakah Anda yakin ingin menghapus tugas ini?") }
                )
            }

            if (showLogoutDialog) {
                AlertDialog(
                    onDismissRequest = { showLogoutDialog = false },
                    confirmButton = {
                        TextButton(onClick = {
                            showLogoutDialog = false
                            onLogout()
                        }) {
                            Text("Keluar")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showLogoutDialog = false }) {
                            Text("Batal")
                        }
                    },
                    title = { Text("Konfirmasi Logout") },
                    text = { Text("Apakah Anda ingin keluar dari aplikasi ini?") }
                )
            }
        }
    }
}

@Composable
fun TaskCard(task: Task, onEdit: () -> Unit, onDelete: () -> Unit, onToggleComplete: () -> Unit) {
    Card(
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF5F5F5)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onToggleComplete() }
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (task.isCompleted) Color.Gray else Color.Black
                )
                Text(
                    text = task.date,
                    fontSize = 14.sp,
                    color = if (task.isCompleted) Color.Gray else Color.Black
                )
                Text(
                    text = task.description,
                    fontSize = 14.sp,
                    color = if (task.isCompleted) Color.Gray else Color.Black
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit Tugas")
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Hapus Tugas")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskInputScreen(onDismiss: () -> Unit, onAddTask: (Task) -> Unit, taskToEdit: Task?) {
    var taskName by remember { mutableStateOf(taskToEdit?.name ?: "") }
    var taskDescription by remember { mutableStateOf(taskToEdit?.description ?: "") }
    var taskDate by remember { mutableStateOf(taskToEdit?.date ?: "") }
    val context = LocalContext.current

    val calendar = Calendar.getInstance()
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val day = calendar.get(Calendar.DAY_OF_MONTH)

    val datePickerDialog = DatePickerDialog(
        context,
        { _, selectedYear, selectedMonth, selectedDay ->
            taskDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
        },
        year, month, day
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = if (taskToEdit != null) "Edit Tugas" else "Tambah Tugas",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = taskName,
            onValueChange = { taskName = it },
            label = { Text("Nama Tugas") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = taskDescription,
            onValueChange = { taskDescription = it },
            label = { Text("Deskripsi Tugas") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = taskDate,
            onValueChange = { taskDate = it },
            label = { Text("Tanggal Tugas") },
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    datePickerDialog.show()
                },
            readOnly = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = { onDismiss() }) {
                Text("Batal")
            }
            Button(onClick = {
                if (taskName.isNotBlank() && taskDate.isNotBlank() && taskDescription.isNotBlank()) {
                    onAddTask(Task(taskName, taskDate, taskDescription))
                }
            }) {
                Text(if (taskToEdit != null) "Edit" else "Tambah")
            }
        }
    }
}